# QClaw 固定收发器 c：离线预检修复版

本轮只做离线验收，不启动 GitHub 收发、QClaw、网关或手机任务。
本包由 ChatGPT 在工作容器中生成；不代表已部署到用户 Windows。

## 本版修改

1. 修复主程序：`preflight` 不再提前计算用户目录或构建状态存储。
2. 需要状态目录的命令若不能解析该目录，返回 `STATE_LOCATION_UNAVAILABLE`，不猜测替代路径。
3. 原始 42 个测试文件逐字节保留；新增 8 个回归测试，共 50 个测试方法。
4. 新增单一离线入口，按程序结果停止，而不是让 Agent 决定失败后是否继续。
5. 校验清单正好包含 8 个其他文件，不包含清单自身。ZIP 共 9 个文件。

不改 GitHub 目标、源提交、消息编号、3 次请求限制、15 秒单步/60 秒收发预算。
不改原 b 版持久状态目录和任务锁。更换版本不授权重放任务或清除锁。
主程序文件名仍为 `qclaw_mailbox_b.py`，以保留原测试和协议兼容性，输出 version 为 c。

## 唯一批准的本轮入口

将 ZIP 解压成独立的 `qclaw-transport-c` 文件夹；不要覆盖旧 b 文件夹。
在已有 Python 3.10+ 的环境中，一次运行：

```powershell
py -3 -B .\qclaw-transport-c\offline_acceptance_c.py
```

也可从 c 程序目录运行 `py -3 -B .\offline_acceptance_c.py`。
脚本按自身文件位置确定程序目录，无需搜索其他工作区。
调用方须设现有执行工具的 30 秒真实进程硬超时；不支持则停止，不研究替代方案。
不增加依赖，不设置全局环境，不提权，不联网下载。

## 程序内固定顺序

- 校验全部 8 个文件，逐项输出文件名和 match。任意不匹配则退出，不加载测试。
- 检查 Python 最低版本。
- 执行原 42 项和新增 8 项离线测试。failfast；任何失败、错误、跳过或数量不足均拒绝预检。
- 仅当全部测试成功，调用主程序的 `preflight`，捕获并输出脱敏结果；从不调用 receive/reconcile。
- 最后退出，不常驻，不安排下一任务。

`GITHUB_AUTH_REQUIRED` 是可接受的离线预检结果：当前调用未提供专用令牌。
`CREDENTIAL_PRESENT_NOT_VERIFIED` 也不授权联网，只说明专用变量存在且格式通过。
入口返回 `offline_passed` 只代表此轮离线验收通过，不代表真实 GitHub/QClaw 连通。

## 限制

入口不调用任何模型，但 Agent 接收任务及运行入口本身仍可能消耗模型额度。
失败阻断由 Python 条件分支执行；本脚本不是 QClaw 全局 token 限额或系统级进程沙箱。
原测试会创建临时文件，并启动两个无网络测试子进程；其超时由原程序控制。
调用方超时或系统拒绝时不要重试，不自动检查/重启/修复其他进程。
不要修改测试、跳过错误、改变 HOME/USERPROFILE 或读取 GitHub 令牌来“通过”验收。
本轮不授予 receive、reconcile、删除状态目录或任何远程写入权限。

## 核查材料

- `SOURCE_REVIEW.md`：源码原因、清单事实及证据范围。
- `original-manifest-check.json`：原 b ZIP 内全部 8 项哈希的实算结果。
- `original-test34-reproduction.txt`：在 Linux 模拟 Path.home 失败，复现原 test_34 错误的日志。

Linux 测试与模拟回归不替代用户 Windows 实机验收。

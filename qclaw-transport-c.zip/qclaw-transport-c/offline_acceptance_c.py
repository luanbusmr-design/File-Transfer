r"""One offline gate: exact manifest -> original and regression tests -> preflight.

No install, retries, downloads, credential discovery, receive or reconcile.
Invoke once: py -3 -B .\offline_acceptance_c.py
Use a 30-second process hard timeout in the caller. This is NOT a global agent
or token limiter; it does enforce stop-on-test-failure without agent judgement.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import unittest

EXPECTED_FILES = frozenset({
    'qclaw_mailbox_b.py', 'test_qclaw_mailbox_b.py', 'offline_acceptance_c.py',
    'test_regression_c.py', 'README.md', 'SOURCE_REVIEW.md',
    'original-manifest-check.json', 'original-test34-reproduction.txt',
})
EXPECTED_TESTS = 50


def verify_manifest(folder: Path) -> list[dict]:
    """Return one outcome for EACH of the eight files. Never ignore a mismatch."""
    manifest_path = folder / 'SHA256SUMS.json'
    if manifest_path.is_symlink() or manifest_path.stat().st_size > 16384:
        raise ValueError('MANIFEST_FILE_INVALID')
    def unique(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError('DUPLICATE_MANIFEST_KEY')
            out[key] = value
        return out
    manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique)
    if not isinstance(manifest, dict) or set(manifest) != EXPECTED_FILES:
        raise ValueError('MANIFEST_KEYS_INVALID_NO_SELF_ENTRY_ALLOWED')
    rows = []
    for name in sorted(EXPECTED_FILES):
        expected = manifest[name]
        if not isinstance(expected, str) or re.fullmatch('[0-9a-f]{64}', expected) is None:
            raise ValueError('MANIFEST_HASH_INVALID')
        p = folder / name
        try:
            if p.is_symlink() or not p.is_file() or p.stat().st_size > 2_000_000:
                raise ValueError('FILE_INVALID')
            actual = hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append({'file': name, 'match': actual == expected})
        except (OSError, ValueError):
            rows.append({'file': name, 'match': False})
    return rows


def run_stages(test_runner, preflight_runner) -> dict:
    """The preflight callable is unreachable when any test fails or is skipped."""
    outcome = test_runner()
    result = {'tests_run': outcome.testsRun, 'test_failures': len(outcome.failures),
              'test_errors': len(outcome.errors), 'tests_skipped': len(outcome.skipped),
              'preflight_executed': False, 'live_receipt_started': False,
              'qclaw_agent_called': False, 'phone_harness_started': False}
    if (not outcome.wasSuccessful() or outcome.skipped or outcome.testsRun != EXPECTED_TESTS):
        return dict(result, status='blocked', reason='OFFLINE_TESTS_NOT_ALL_PASSED')
    code, preflight = preflight_runner()
    result.update(preflight_executed=True, preflight=preflight, preflight_exit_code=code)
    expected = ((code == 2 and preflight.get('status') == 'needs_approval'
                 and preflight.get('reason') == 'GITHUB_AUTH_REQUIRED')
                or (code == 0 and preflight.get('status') == 'ready_for_manual_run'
                    and preflight.get('reason') == 'CREDENTIAL_PRESENT_NOT_VERIFIED'))
    if not expected or preflight.get('network_attempts_this_run') != 0:
        return dict(result, status='blocked', reason='PREFLIGHT_NOT_ACCEPTED')
    return dict(result, status='offline_passed', reason='STOP_BEFORE_ANY_LIVE_RECEIPT')


def main() -> int:
    if len(sys.argv) != 1:
        print(json.dumps({'status':'blocked', 'reason':'NO_ARGUMENTS_ACCEPTED'}))
        return 2
    folder = Path(__file__).resolve().parent
    try:
        rows = verify_manifest(folder)
        print(json.dumps({'stage':'integrity', 'passed':sum(r['match'] for r in rows),
                          'total':len(rows), 'files':rows}), flush=True)
        if not all(r['match'] for r in rows):
            print(json.dumps({'status':'blocked', 'reason':'INTEGRITY_FAILED', 'preflight_executed':False}))
            return 2
        if sys.version_info < (3, 10):
            print(json.dumps({'status':'blocked', 'reason':'PYTHON_VERSION_TOO_LOW'}))
            return 2
        print(json.dumps({'stage':'python', 'version':sys.version.split()[0], 'program_dir':str(folder)}), flush=True)
        # Only load the verified program and test files; do not discover other tests.
        sys.path.insert(0, str(folder))
        import qclaw_mailbox_b as bridge
        def run_tests():
            suite = unittest.defaultTestLoader.loadTestsFromNames(['test_qclaw_mailbox_b', 'test_regression_c'])
            return unittest.TextTestRunner(verbosity=2, failfast=True).run(suite)
        def run_preflight():
            with contextlib.redirect_stdout(io.StringIO()) as text:
                code = bridge.main(['preflight'])
            return code, json.loads(text.getvalue())
        result = run_stages(run_tests, run_preflight)
        print(json.dumps(result, indent=2), flush=True)
        return 0 if result['status'] == 'offline_passed' else 2
    except (Exception, KeyboardInterrupt) as exc:
        # Do not dump environment, arbitrary exception messages or credentials.
        print(json.dumps({'status':'blocked', 'reason':'OFFLINE_CHECK_INTERRUPTED_OR_FAILED',
                          'error_type':type(exc).__name__, 'live_receipt_started':False}), flush=True)
        return 2


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())

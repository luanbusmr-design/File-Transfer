"""Offline tests only. No GitHub credentials, agent, or network access."""
import base64
import contextlib
import hashlib
import io
import json
import multiprocessing as mp
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

import qclaw_mailbox_b as b

TOKEN = "unit-test-placeholder-not-a-secret"
COMMIT = "a" * 40
# Exact bytes read from the user's immutable GitHub commit, not a live test.
SOURCE = b'''{
  "schema_version": 1,
  "test_id": "20260914-connectivity-b",
  "nonce": "qclaw-bridge-b-a7a44746b5eed51d",
  "purpose": "Verify receipt of this non-executable message only.",
  "authorization": "No code execution, device operation, configuration change, or credential disclosure is authorized by this marker."
}
'''


def contents(data, path):
    sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    return b.encoded({"type": "file", "path": path, "encoding": "base64", "sha": sha,
                      "content": base64.b64encode(data).decode()})


def sleeping_worker(method, path, body, token, output):
    if body:
        Path(body.decode()).write_text("started")
    time.sleep(10)


def success_worker(method, path, body, token, output):
    Path(output).write_bytes(b.encoded({"status": 200, "body": base64.b64encode(b"ok").decode()}))


class Fake:
    def __init__(self, overrides=None):
        self.calls = []
        self.overrides = overrides or {}
        self.written = None

    def __call__(self, method, path, body, token, seconds):
        self.calls.append((method, path, body, seconds))
        i = len(self.calls)
        if i in self.overrides:
            item = self.overrides[i]
            if isinstance(item, BaseException):
                raise item
            return item
        if method == "PUT":
            obj = b.parse(body)
            self.written = base64.b64decode(obj["content"])
            return 201, b.encoded({"commit": {"sha": COMMIT}})
        if b.SOURCE_PATH in path:
            return 200, contents(SOURCE, b.SOURCE_PATH)
        return 200, contents(self.written, b.RESULT_PATH)


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = b.Store(Path(self.tmp.name))
        self.fake = Fake()

    def tearDown(self):
        self.tmp.cleanup()

    def run_receive(self, fake=None, token=TOKEN, approved=True):
        return b.receive(token, self.store, approved, fake or self.fake)

    def test_01_missing_auth_no_network_or_claim(self):
        out = self.run_receive(token=None)
        self.assertEqual(out["status"], "needs_approval")
        self.assertEqual(self.fake.calls, [])
        self.assertFalse(self.store.folder.exists())

    def test_02_missing_approval_no_network_or_claim(self):
        out = self.run_receive(approved=False)
        self.assertEqual(out["reason"], "RECEIPT_WRITE_APPROVAL_REQUIRED")
        self.assertFalse(self.store.folder.exists())
        self.assertEqual(self.fake.calls, [])

    def test_03_malformed_auth_no_network(self):
        for bad in ("abc", "abc\ndefghi", "secret with spaces"):
            self.assertEqual(self.run_receive(token=bad)["status"], "needs_approval")
        self.assertEqual(self.fake.calls, [])

    def test_04_success_exactly_three_calls(self):
        out = self.run_receive()
        self.assertEqual(out["status"], "completed")
        self.assertEqual([x[0] for x in self.fake.calls], ["GET", "PUT", "GET"])
        self.assertEqual(out["network_attempts_this_run"], 3)

    def test_05_source_commit_and_hash_pinned(self):
        self.assertEqual(b.decode_contents(contents(SOURCE, b.SOURCE_PATH), b.SOURCE_PATH, b.SOURCE_BLOB), SOURCE)
        self.run_receive()
        self.assertTrue(self.fake.calls[0][1].endswith(b.SOURCE_COMMIT))

    def test_06_put_is_create_only_nonproduction(self):
        self.run_receive()
        body = b.parse(self.fake.calls[1][2])
        self.assertNotIn("sha", body)
        self.assertEqual(body["branch"], "qclaw-bridge-a")
        self.assertEqual(self.fake.calls[1][1], b.PREFIX + b.RESULT_PATH)

    def test_07_verification_uses_returned_immutable_commit(self):
        self.run_receive()
        self.assertTrue(self.fake.calls[2][1].endswith(COMMIT))

    def test_08_receipt_truthful_no_agent_claims(self):
        self.run_receive()
        receipt = b.parse(self.fake.written)
        for key in ("qclaw_agent_called", "automatic_polling_verified", "gateway_tested_this_round", "phone_harness_started"):
            self.assertIs(receipt[key], False)
        self.assertEqual(receipt["model_calls"], 0)
        self.assertEqual(receipt["nonce"], b.parse(SOURCE)["nonce"])

    def test_09_source_404_is_ambiguous_one_call(self):
        fake = Fake({1: (404, b"private or missing")})
        out = self.run_receive(fake)
        self.assertEqual(out["reason"], "HTTP_404_AMBIGUOUS")
        self.assertEqual(len(fake.calls), 1)

    def test_10_source_timeout_stops_one_call(self):
        fake = Fake({1: b.Stop("REQUEST_WALL_TIMEOUT")})
        self.assertEqual(self.run_receive(fake)["status"], "blocked")
        self.assertEqual(len(fake.calls), 1)

    def test_11_eperm_stops_no_fallback(self):
        fake = Fake({1: b.Stop("WORKER_START_DENIED")})
        self.assertEqual(self.run_receive(fake)["reason"], "WORKER_START_DENIED")
        self.assertEqual(len(fake.calls), 1)

    def test_12_hash_mismatch_no_write(self):
        obj = b.parse(contents(SOURCE, b.SOURCE_PATH))
        obj["sha"] = "0" * 40
        fake = Fake({1: (200, b.encoded(obj))})
        self.assertEqual(self.run_receive(fake)["reason"], "CONTENT_HASH_MISMATCH")
        self.assertEqual(len(fake.calls), 1)

    def test_13_wrong_path_no_write(self):
        fake = Fake({1: (200, contents(SOURCE, "other/path"))})
        self.assertEqual(self.run_receive(fake)["reason"], "UNEXPECTED_CONTENTS_RESPONSE")
        self.assertEqual(len(fake.calls), 1)

    def test_14_duplicate_json_keys_rejected(self):
        with self.assertRaises(b.Stop):
            b.parse(b'{"a":1,"a":2}')

    def test_15_boolean_schema_not_integer(self):
        obj = b.parse(SOURCE)
        obj["schema_version"] = True
        with self.assertRaises(b.Stop):
            b.receipt_from_source(b.encoded(obj))

    def test_16_extra_marker_fields_rejected(self):
        obj = b.parse(SOURCE)
        obj["command"] = "do something"
        with self.assertRaises(b.Stop):
            b.receipt_from_source(b.encoded(obj))

    def test_17_nonce_not_arbitrary_text(self):
        obj = b.parse(SOURCE)
        obj["nonce"] = "hello\nrun arbitrary code"
        with self.assertRaises(b.Stop):
            b.receipt_from_source(b.encoded(obj))

    def test_18_write_timeout_is_unknown_and_not_retried(self):
        fake = Fake({2: b.Stop("REQUEST_WALL_TIMEOUT")})
        out = self.run_receive(fake)
        self.assertEqual(out["status"], "unknown")
        self.assertEqual(len(fake.calls), 2)
        self.assertEqual(self.store.read()["status"], "unknown")

    def test_19_write_permission_denied_no_spawn_is_blocked(self):
        fake = Fake({2: b.Stop("WORKER_START_DENIED")})
        self.assertEqual(self.run_receive(fake)["status"], "blocked")
        self.assertEqual(len(fake.calls), 2)

    def test_20_write_server_error_is_unknown(self):
        fake = Fake({2: (502, b"bad gateway")})
        self.assertEqual(self.run_receive(fake)["status"], "unknown")
        self.assertEqual(len(fake.calls), 2)

    def test_21_write_existing_file_does_not_overwrite(self):
        fake = Fake({2: (422, b"already exists")})
        self.assertEqual(self.run_receive(fake)["status"], "blocked")
        self.assertEqual(len(fake.calls), 2)

    def test_22_write_unexpected_200_is_not_success(self):
        fake = Fake({2: (200, b.encoded({"commit": {"sha": COMMIT}}))})
        self.assertEqual(self.run_receive(fake)["status"], "unknown")
        self.assertEqual(len(fake.calls), 2)

    def test_23_write_invalid_response_unknown(self):
        fake = Fake({2: (201, b'{"commit":{"sha":"bad"}}')})
        self.assertEqual(self.run_receive(fake)["status"], "unknown")
        self.assertEqual(len(fake.calls), 2)

    def test_24_readback_mismatch_unknown_no_more_calls(self):
        fake = Fake({3: (200, contents(b'{}\n', b.RESULT_PATH))})
        self.assertEqual(self.run_receive(fake)["status"], "unknown")
        self.assertEqual(len(fake.calls), 3)

    def test_25_duplicate_run_has_zero_calls(self):
        self.run_receive()
        second = Fake()
        self.assertEqual(self.run_receive(second)["reason"], "TASK_ALREADY_CLAIMED_NO_REPLAY")
        self.assertEqual(second.calls, [])
        self.assertEqual(self.store.read()["status"], "completed")

    def test_26_failed_run_also_latches(self):
        self.run_receive(Fake({1: (401, b"unauthorized")}))
        second = Fake()
        self.assertEqual(self.run_receive(second)["reason"], "TASK_ALREADY_CLAIMED_NO_REPLAY")
        self.assertEqual(second.calls, [])

    def test_27_interrupted_empty_claim_latches(self):
        self.store.claim()
        self.assertEqual(self.run_receive()["reason"], "TASK_ALREADY_CLAIMED_NO_REPLAY")
        self.assertEqual(self.fake.calls, [])

    def test_28_fourth_request_budget_rejected(self):
        budget = b.Budget()
        for _ in range(3):
            self.assertLessEqual(budget.reserve(), 15)
        with self.assertRaises(b.Stop):
            budget.reserve()

    def test_29_expired_total_budget_rejected(self):
        with self.assertRaises(b.Stop):
            b.Budget(seconds=0).reserve()

    def test_30_write_checkpoint_exists_before_transport(self):
        def checked(method, path, body, token, seconds):
            state = self.store.read()
            if method == "PUT":
                self.assertEqual(state["reason"], "write_receipt")
                self.assertIsInstance(state["pending_receipt"], dict)
            return self.fake(method, path, body, token, seconds)
        self.assertEqual(self.run_receive(checked)["status"], "completed")

    def test_31_unknown_reconcile_one_read_no_write(self):
        self.run_receive(Fake({2: b.Stop("REQUEST_WALL_TIMEOUT")}))
        pending = self.store.read()["pending_receipt"]
        fake = Fake({1: (200, contents(b.encoded(pending), b.RESULT_PATH))})
        out = b.reconcile(TOKEN, self.store, True, fake)
        self.assertEqual(out["status"], "completed")
        self.assertEqual([x[0] for x in fake.calls], ["GET"])

    def test_32_reconcile_requires_explicit_approval(self):
        self.assertEqual(b.reconcile(TOKEN, self.store, False, self.fake)["status"], "needs_approval")
        self.assertEqual(self.fake.calls, [])

    def test_33_reconcile_404_retains_unknown(self):
        self.run_receive(Fake({2: b.Stop("REQUEST_WALL_TIMEOUT")}))
        fake = Fake({1: (404, b"missing")})
        self.assertEqual(b.reconcile(TOKEN, self.store, True, fake)["status"], "unknown")
        self.assertEqual(self.store.read()["status"], "unknown")
        self.assertEqual(len(fake.calls), 1)

    def test_34_preflight_has_no_process_network_or_state_write(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(b.mp, "get_context") as process, \
                patch.object(b.http.client, "HTTPSConnection") as http, \
                patch.object(b.Store, "claim") as claim, contextlib.redirect_stdout(io.StringIO()) as text:
            self.assertEqual(b.main(["preflight"]), 2)
            self.assertEqual(json.loads(text.getvalue())["network_attempts_this_run"], 0)
            process.assert_not_called()
            http.assert_not_called()
            claim.assert_not_called()

    def test_35_credentials_never_in_report_or_journal(self):
        self.run_receive(Fake({1: RuntimeError(TOKEN)}))
        self.assertNotIn(TOKEN, (self.store.folder / "journal.json").read_text())

    def test_36_route_allowlist_rejects_alternate_hosts_and_paths(self):
        for method, path in (("POST", b.PREFIX + b.RESULT_PATH), ("GET", "https://evil.invalid"),
                             ("PUT", b.PREFIX + "README.md"), ("GET", b.PREFIX + b.SOURCE_PATH + "?ref=main")):
            self.assertFalse(b.route_allowed(method, path))

    def test_37_redirect_response_is_not_followed(self):
        fake = Fake({1: (302, b"redirect")})
        self.assertEqual(self.run_receive(fake)["reason"], "HTTP_302")
        self.assertEqual(len(fake.calls), 1)

    def test_38_real_spawn_watchdog_kills_sleeping_worker(self):
        before = {p.pid for p in mp.active_children()}
        start = time.monotonic()
        marker = Path(self.tmp.name) / "worker-started.txt"
        with self.assertRaisesRegex(b.Stop, "REQUEST_WALL_TIMEOUT"):
            b.isolated_request("GET", b.PREFIX + b.SOURCE_PATH + "?ref=" + b.SOURCE_COMMIT,
                               str(marker).encode(), TOKEN, 1.8, worker=sleeping_worker)
        self.assertLess(time.monotonic() - start, 3.0)
        self.assertTrue(marker.exists(), "test must kill a started worker, not just its startup")
        self.assertEqual({p.pid for p in mp.active_children()}, before)

    def test_39_real_spawn_result_success(self):
        status, data = b.isolated_request("GET", b.PREFIX + b.SOURCE_PATH + "?ref=" + b.SOURCE_COMMIT,
                                         None, TOKEN, 3, worker=success_worker)
        self.assertEqual((status, data), (200, b"ok"))

    def test_40_spawn_eperm_returns_once_no_alternative(self):
        ctx = Mock()
        process = ctx.Process.return_value
        process.start.side_effect = PermissionError("EPERM")
        with patch.object(b.mp, "get_context", return_value=ctx) as getter:
            with self.assertRaisesRegex(b.Stop, "WORKER_START_DENIED"):
                b.isolated_request("GET", b.PREFIX + b.SOURCE_PATH + "?ref=" + b.SOURCE_COMMIT,
                                   None, TOKEN, 2)
            self.assertEqual(getter.call_count, 1)
            process.start.assert_called_once()

    def test_41_http_worker_never_inherits_proxy_and_caps_response(self):
        response = Mock(status=200)
        response.read.return_value = b"a" * (b.MAX_RESPONSE + 1)
        conn = Mock()
        conn.getresponse.return_value = response
        target = str(Path(self.tmp.name) / "http.json")
        with patch.dict(os.environ, {"HTTPS_PROXY": "http://unwanted-proxy.invalid:99"}), \
                patch.object(b.http.client, "HTTPSConnection", return_value=conn) as factory:
            b._http_worker("GET", b.PREFIX + b.SOURCE_PATH + "?ref=" + b.SOURCE_COMMIT, None, TOKEN, target)
            self.assertEqual(factory.call_args.args[0], "api.github.com")
            response.read.assert_called_once_with(b.MAX_RESPONSE + 1)
            self.assertEqual(b.parse(Path(target).read_bytes())["error"], "RESPONSE_TOO_LARGE")

    def test_42_body_never_contains_token(self):
        self.run_receive()
        for method, path, body, _ in self.fake.calls:
            self.assertNotIn(TOKEN, path)
            if body:
                self.assertNotIn(TOKEN.encode(), body)


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Additive offline regression tests. The original 42 tests are unchanged."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

import qclaw_mailbox_b as b
import offline_acceptance_c as gate


class RegressionC(unittest.TestCase):
    def call_main(self, args):
        with contextlib.redirect_stdout(io.StringIO()) as text:
            code = b.main(args)
        return code, json.loads(text.getvalue())

    def test_c01_preflight_missing_home_does_not_resolve_state(self):
        with patch.dict(os.environ, {}, clear=True), \
             patch.object(Path, 'home', side_effect=RuntimeError('no home')) as home, \
             patch.object(b, 'state_root', side_effect=AssertionError('no state lookup')) as state, \
             patch.object(b, 'Store', side_effect=AssertionError('no Store')) as store:
            code, result = self.call_main(['preflight'])
        self.assertEqual((code, result['reason']), (2, 'GITHUB_AUTH_REQUIRED'))
        home.assert_not_called(); state.assert_not_called(); store.assert_not_called()

    def test_c02_preflight_placeholder_auth_no_home_required(self):
        token = 'unit-test-placeholder-not-a-secret'
        with patch.dict(os.environ, {b.TOKEN_ENV:token}, clear=True), \
             patch.object(b, 'state_root', side_effect=AssertionError('no state lookup')) as state:
            code, result = self.call_main(['preflight'])
        self.assertEqual((code, result['reason']), (0, 'CREDENTIAL_PRESENT_NOT_VERIFIED'))
        self.assertNotIn(token, json.dumps(result)); state.assert_not_called()

    def test_c03_default_mode_remains_offline_without_home(self):
        with patch.dict(os.environ, {}, clear=True), \
             patch.object(Path, 'home', side_effect=RuntimeError('no home')) as home:
            code, result = self.call_main([])
        self.assertEqual((code, result['reason']), (2, 'GITHUB_AUTH_REQUIRED'))
        home.assert_not_called()

    def test_c04_state_modes_home_failure_return_blocked_without_io(self):
        with patch.dict(os.environ, {}, clear=True), \
             patch.object(Path, 'home', side_effect=RuntimeError('no home')), \
             patch.object(b.mp, 'get_context') as process, \
             patch.object(b.http.client, 'HTTPSConnection') as http, \
             patch.object(b.Store, 'claim') as claim:
            for args in (['status'], ['receive', '--approve-receipt'], ['reconcile', '--approve-read']):
                with self.subTest(args=args):
                    code, result = self.call_main(args)
                    self.assertEqual((code, result['reason']), (2, 'STATE_LOCATION_UNAVAILABLE'))
                    self.assertEqual(result['network_attempts_this_run'], 0)
            process.assert_not_called(); http.assert_not_called(); claim.assert_not_called()

    def test_c05_durable_state_root_and_protocol_not_reset(self):
        key = 'LOCALAPPDATA' if os.name == 'nt' else 'XDG_STATE_HOME'
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {key:temp}):
            self.assertEqual(b.state_root(), Path(temp)/'solo-company-hub'/'qclaw-transport-b')
            self.assertEqual(b.Store(b.state_root()).folder.name, '20260914-connectivity-b')
        self.assertEqual(b.BRANCH, 'qclaw-bridge-a')
        self.assertEqual(b.RESULT_PATH, 'handoffs/qclaw/connectivity-b.result.json')
        self.assertEqual((b.MAX_REQUESTS, b.TOTAL_SECONDS, b.REQUEST_SECONDS), (3, 60., 15.))

    def test_c06_failed_test_result_blocks_preflight(self):
        outcome = Mock(testsRun=1, failures=[], errors=[('test','error')], skipped=[])
        outcome.wasSuccessful.return_value = False
        preflight = Mock(side_effect=AssertionError('must not run'))
        result = gate.run_stages(lambda:outcome, preflight)
        self.assertEqual(result['status'], 'blocked')
        self.assertFalse(result['preflight_executed']); preflight.assert_not_called()

    def test_c07_skipped_or_missing_tests_also_block_preflight(self):
        for count, skipped in ((50, [('test','skip')]), (49, [])):
            with self.subTest(count=count, skipped=skipped):
                outcome = Mock(testsRun=count, failures=[], errors=[], skipped=skipped)
                outcome.wasSuccessful.return_value = True
                preflight = Mock(side_effect=AssertionError('must not run'))
                self.assertEqual(gate.run_stages(lambda:outcome, preflight)['status'], 'blocked')
                preflight.assert_not_called()

    def test_c08_integrity_checks_all_eight_and_rejects_self_entry(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            checksums = {}
            for name in gate.EXPECTED_FILES:
                raw = (name+'\n').encode()
                (root/name).write_bytes(raw)
                checksums[name] = hashlib.sha256(raw).hexdigest()
            m = root/'SHA256SUMS.json'
            m.write_text(json.dumps(checksums))
            self.assertEqual(sum(r['match'] for r in gate.verify_manifest(root)),8)
            (root/'README.md').write_bytes(b'changed')
            rows = gate.verify_manifest(root)
            self.assertEqual(len(rows),8)
            self.assertEqual([r['file'] for r in rows if not r['match']], ['README.md'])
            checksums['SHA256SUMS.json'] = '0'*64
            m.write_text(json.dumps(checksums))
            with self.assertRaises(ValueError):
                gate.verify_manifest(root)


if __name__ == '__main__':
    unittest.main(verbosity=2)

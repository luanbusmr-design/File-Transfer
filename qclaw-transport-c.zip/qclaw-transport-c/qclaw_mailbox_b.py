"""Fixed GitHub receipt transport b; stdlib only; no agent, shell, or GCM.

Default: offline preflight. Live write: receive --approve-receipt.
Never import this transport into an unbounded agent loop.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import http.client
import json
import multiprocessing as mp
import os
from pathlib import Path
import re
import ssl
import sys
import time
import tempfile
from typing import Callable

VERSION = "c"
REPO = "luanbusmr-design/solo-company-hub"
BRANCH = "qclaw-bridge-a"
SOURCE_COMMIT = "add30037d2f89c228739ecbb4a3f3fbf59ddabfe"
SOURCE_BLOB = "75f5d4c90a48d8465b8fbd65fb391b988543bd0b"
SOURCE_PATH = "handoffs/qclaw/connectivity-b.json"
RESULT_PATH = "handoffs/qclaw/connectivity-b.result.json"
TEST_ID = "20260914-connectivity-b"
TOKEN_ENV = "QCLAW_BRIDGE_GITHUB_TOKEN"
MAX_REQUESTS = 3
TOTAL_SECONDS = 60.0
REQUEST_SECONDS = 15.0
MAX_RESPONSE = 65536
SHA = re.compile(r"[0-9a-f]{40}\Z")
PREFIX = f"/repos/{REPO}/contents/"


class Stop(Exception):
    def __init__(self, reason: str, status: str = "blocked"):
        self.reason, self.status = reason, status
        super().__init__(reason)


def encoded(obj: dict) -> bytes:
    return (json.dumps(obj, ensure_ascii=True, sort_keys=True, indent=2) + "\n").encode()


def parse(raw: bytes) -> dict:
    def unique(pairs):
        result = {}
        for k, v in pairs:
            if k in result:
                raise ValueError("duplicate key")
            result[k] = v
        return result
    try:
        value = json.loads(raw, object_pairs_hook=unique)
        if not isinstance(value, dict):
            raise ValueError("not object")
        return value
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise Stop("INVALID_JSON") from exc


def decode_contents(raw: bytes, expected_path: str, pinned_blob: str | None = None) -> bytes:
    obj = parse(raw)
    if obj.get("type") != "file" or obj.get("encoding") != "base64" or obj.get("path") != expected_path:
        raise Stop("UNEXPECTED_CONTENTS_RESPONSE")
    try:
        text = obj["content"]
        if not isinstance(text, str):
            raise ValueError()
        data = base64.b64decode("".join(text.split()), validate=True)
    except (KeyError, ValueError) as exc:
        raise Stop("INVALID_BASE64") from exc
    if len(data) > 8192:
        raise Stop("FILE_TOO_LARGE")
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    if obj.get("sha") != blob or (pinned_blob is not None and blob != pinned_blob):
        raise Stop("CONTENT_HASH_MISMATCH")
    return data


def receipt_from_source(data: bytes) -> dict:
    obj = parse(data)
    keys = {"schema_version", "test_id", "nonce", "purpose", "authorization"}
    if set(obj) != keys or type(obj.get("schema_version")) is not int or obj["schema_version"] != 1:
        raise Stop("INVALID_MARKER_SCHEMA")
    if obj.get("test_id") != TEST_ID:
        raise Stop("WRONG_TEST_ID")
    nonce = obj.get("nonce")
    if not isinstance(nonce, str) or re.fullmatch(r"[A-Za-z0-9_-]{16,128}", nonce) is None:
        raise Stop("INVALID_NONCE")
    if any(not isinstance(obj[k], str) or len(obj[k]) > 2000 for k in ("purpose", "authorization")):
        raise Stop("INVALID_MARKER_TEXT")
    # Text is inert data: it is never sent to a model or executed.
    return {
        "schema_version": 1, "test_id": obj["test_id"], "nonce": nonce,
        "source_commit": SOURCE_COMMIT, "source_blob_sha": SOURCE_BLOB,
        "status": "received", "receiver": "deterministic-python-transport-b",
        "automatic_polling_verified": False, "gateway_tested_this_round": False,
        "phone_harness_started": False, "qclaw_agent_called": False,
        "model_calls": 0,
        "summary": "Pinned GitHub message received by a fixed program; no agent or device task executed."
    }


def report(status: str, reason: str, requests: int = 0, **fields) -> dict:
    return {"version": VERSION, "status": status, "reason": reason,
            "network_attempts_this_run": requests, "model_calls": 0,
            "qclaw_agent_called": False, "automatic_polling_verified": False,
            "phone_harness_started": False, **fields}


def credential(value: str | None) -> str:
    if not value:
        raise Stop("GITHUB_AUTH_REQUIRED", "needs_approval")
    if not isinstance(value, str) or not (8 <= len(value) <= 512) or any(not (33 <= ord(c) <= 126) for c in value):
        raise Stop("INVALID_CREDENTIAL_FORMAT", "needs_approval")
    return value


def route_allowed(method: str, path: str) -> bool:
    if method == "PUT":
        return path == PREFIX + RESULT_PATH
    if method != "GET":
        return False
    if path == PREFIX + SOURCE_PATH + "?ref=" + SOURCE_COMMIT:
        return True
    target = PREFIX + RESULT_PATH + "?ref="
    return path.startswith(target) and (path[len(target):] == BRANCH or SHA.fullmatch(path[len(target):]) is not None)


def _http_worker(method: str, path: str, body: bytes | None, token: str, output: str) -> None:
    """One HTTPS request only. Does not consult proxy environment or redirect."""
    conn = None
    try:
        if not route_allowed(method, path):
            raise Stop("ROUTE_NOT_ALLOWED")
        conn = http.client.HTTPSConnection("api.github.com", timeout=REQUEST_SECONDS,
                                           context=ssl.create_default_context())
        conn.set_debuglevel(0)
        headers = {"Authorization": "Bearer " + token, "Accept": "application/vnd.github+json",
                   "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "qclaw-transport-b",
                   "Content-Type": "application/json"}
        conn.request(method, path, body=body, headers=headers)
        res = conn.getresponse()
        raw = res.read(MAX_RESPONSE + 1)
        message = ({"error": "RESPONSE_TOO_LARGE"} if len(raw) > MAX_RESPONSE else
                   {"status": res.status, "body": base64.b64encode(raw).decode()})
    except Stop as exc:
        message = {"error": exc.reason}
    except Exception:
        # Never return exception text, URLs, headers, or credentials.
        message = {"error": "NETWORK_OR_TLS_ERROR"}
    finally:
        if conn is not None:
            conn.close()
    Path(output).write_bytes(encoded(message))


def stop_process(process) -> None:
    if process.is_alive():
        process.terminate()
        process.join(0.15)
    if process.is_alive():
        process.kill()
        process.join(0.15)
    if process.is_alive():
        raise Stop("WORKER_TERMINATION_UNCONFIRMED", "unknown")
    process.join(0)
    process.close()


def isolated_request(method: str, path: str, body: bytes | None, token: str,
                     seconds: float, *, worker: Callable = _http_worker) -> tuple[int, bytes]:
    """Wait for child exit, not an unbounded Pipe.recv after readability.
    Parent deadline includes DNS, TLS, and response body read.
    """
    if not route_allowed(method, path):
        raise Stop("ROUTE_NOT_ALLOWED")
    end = time.monotonic() + max(0.0, seconds - 0.35)  # reserve teardown time
    ctx = mp.get_context("spawn")
    with tempfile.TemporaryDirectory(prefix="qclaw-transport-b-") as temp:
        output = Path(temp) / "response.json"
        process = ctx.Process(target=worker, args=(method, path, body, token, str(output)), daemon=True)
        started = False
        try:
            try:
                process.start()
                started = True
            except (OSError, RuntimeError):
                raise Stop("WORKER_START_DENIED") from None
            process.join(max(0.0, end - time.monotonic()))
            if process.is_alive():
                raise Stop("REQUEST_WALL_TIMEOUT")
            if process.exitcode != 0 or not output.exists():
                raise Stop("WORKER_INTERRUPTED")
            if output.stat().st_size > MAX_RESPONSE * 2:
                raise Stop("RESPONSE_TOO_LARGE")
            message = parse(output.read_bytes())
            if "error" in message:
                raise Stop(message["error"])
            raw = base64.b64decode(message["body"], validate=True)
            if len(raw) > MAX_RESPONSE:
                raise Stop("RESPONSE_TOO_LARGE")
            return message["status"], raw
        finally:
            if started:
                stop_process(process)
            else:
                process.close()


def state_root() -> Path:
    root = os.environ.get("LOCALAPPDATA") if os.name == "nt" else os.environ.get("XDG_STATE_HOME")
    return (Path(root) if root else Path.home() / ".local" / "state") / "solo-company-hub" / "qclaw-transport-b"


class Store:
    def __init__(self, root: Path):
        self.folder = root / TEST_ID

    def claim(self) -> None:
        self.folder.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.folder.mkdir()  # atomic single-writer, also a durable stop latch
        except FileExistsError:
            raise Stop("TASK_ALREADY_CLAIMED_NO_REPLAY") from None

    def write(self, obj: dict) -> None:
        temp = self.folder / "journal.tmp"
        with temp.open("wb") as f:
            f.write(encoded(obj))
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, self.folder / "journal.json")

    def read(self) -> dict:
        try:
            data = (self.folder / "journal.json").read_bytes()
        except FileNotFoundError:
            raise Stop("NO_JOURNAL_OR_INTERRUPTED_CLAIM") from None
        if len(data) > MAX_RESPONSE:
            raise Stop("INVALID_LOCAL_JOURNAL")
        return parse(data)


class Budget:
    def __init__(self, limit: int = MAX_REQUESTS, seconds: float = TOTAL_SECONDS):
        self.end = time.monotonic() + seconds
        self.count = 0
        self.limit = min(limit, MAX_REQUESTS)

    def reserve(self) -> float:
        left = self.end - time.monotonic()
        if self.count >= self.limit:
            raise Stop("REQUEST_BUDGET_EXHAUSTED")
        if left <= 0.5:
            raise Stop("TOTAL_DEADLINE_EXHAUSTED")
        self.count += 1
        return min(REQUEST_SECONDS, left)


def receive(token: str | None, store: Store, approved: bool,
            transport: Callable = isolated_request) -> dict:
    budget = Budget()
    stage = "preflight"
    pending = None
    claimed = False
    mutation_possible = False
    try:
        if not approved:
            raise Stop("RECEIPT_WRITE_APPROVAL_REQUIRED", "needs_approval")
        token = credential(token)
        store.claim()
        claimed = True

        def request(method, path, body=None):
            nonlocal stage, mutation_possible
            seconds = budget.reserve()
            stage = {1: "read_source", 2: "write_receipt", 3: "verify_receipt"}[budget.count]
            store.write(report("running", stage, budget.count, pending_receipt=pending))
            if method == "PUT":
                mutation_possible = True  # journal persisted before dispatch
            try:
                status, raw = transport(method, path, body, token, seconds)
            except Stop as exc:
                if method == "PUT" and exc.reason == "WORKER_START_DENIED":
                    mutation_possible = False
                raise
            if status not in (200, 201):
                if method == "PUT" and 400 <= status < 500:
                    mutation_possible = False  # definitive client rejection; never retry
                reason = "HTTP_404_AMBIGUOUS" if status == 404 else "HTTP_" + str(status)
                raise Stop(reason)
            if method == "PUT" and status != 201:
                raise Stop("WRITE_NOT_CONFIRMED_CREATED")
            if method == "GET" and status != 200:
                raise Stop("UNEXPECTED_HTTP_STATUS")
            return raw

        raw = request("GET", PREFIX + SOURCE_PATH + "?ref=" + SOURCE_COMMIT)
        pending = receipt_from_source(decode_contents(raw, SOURCE_PATH, SOURCE_BLOB))
        expected = encoded(pending)
        body = encoded({"message": "Acknowledge fixed connectivity marker (no agent execution)",
                        "branch": BRANCH, "content": base64.b64encode(expected).decode()})
        created = parse(request("PUT", PREFIX + RESULT_PATH, body))  # no sha: create-only
        commit = created.get("commit", {}).get("sha")
        if not isinstance(commit, str) or not SHA.fullmatch(commit):
            raise Stop("INVALID_WRITE_RESPONSE")
        observed = request("GET", PREFIX + RESULT_PATH + "?ref=" + commit)
        if decode_contents(observed, RESULT_PATH) != expected:
            raise Stop("RECEIPT_VERIFICATION_MISMATCH")
        result = report("completed", "RECEIPT_READ_BACK_VERIFIED", budget.count,
                        receipt_commit=commit, source_commit=SOURCE_COMMIT)
    except Stop as exc:
        state = "unknown" if mutation_possible else exc.status
        result = report(state, exc.reason, budget.count, stage=stage, pending_receipt=pending)
    except KeyboardInterrupt:
        result = report("unknown" if mutation_possible else "blocked", "USER_INTERRUPTED",
                        budget.count, stage=stage, pending_receipt=pending)
    except Exception:
        result = report("unknown" if mutation_possible else "blocked", "LOCAL_OPERATION_FAILED",
                        budget.count, stage=stage, pending_receipt=pending)
    if claimed:
        try:
            store.write(result)
        except OSError:
            return report("unknown", "JOURNAL_SAVE_FAILED_CLAIM_RETAINED", budget.count)
    return result


def reconcile(token: str | None, store: Store, approved: bool,
              transport: Callable = isolated_request) -> dict:
    """Explicit one-read operation only; never repeats a PUT or executes a task."""
    budget = Budget(limit=1)
    try:
        if not approved:
            raise Stop("READ_APPROVAL_REQUIRED", "needs_approval")
        token = credential(token)
        old = store.read()
        pending = old.get("pending_receipt")
        if old.get("status") != "unknown" or not isinstance(pending, dict):
            raise Stop("NO_UNKNOWN_RECEIPT_TO_RECONCILE")
        status, raw = transport("GET", PREFIX + RESULT_PATH + "?ref=" + BRANCH,
                                None, token, budget.reserve())
        if status != 200:
            raise Stop("RECONCILIATION_INCONCLUSIVE_HTTP_" + str(status), "unknown")
        if decode_contents(raw, RESULT_PATH) != encoded(pending):
            raise Stop("RECONCILIATION_MISMATCH", "unknown")
        result = report("completed", "READ_ONLY_RECONCILIATION_VERIFIED", budget.count,
                        previous_network_attempts=old.get("network_attempts_this_run"))
        store.write(result)
        return result
    except Stop as exc:
        return report(exc.status, exc.reason, budget.count)
    except KeyboardInterrupt:
        return report("unknown", "RECONCILIATION_INTERRUPTED", budget.count)
    except Exception:
        return report("unknown", "RECONCILIATION_LOCAL_ERROR", budget.count)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", nargs="?", choices=("preflight", "receive", "status", "reconcile"), default="preflight")
    parser.add_argument("--approve-receipt", action="store_true")
    parser.add_argument("--approve-read", action="store_true")
    args = parser.parse_args(argv)
    # Offline preflight must not resolve a home directory or construct a store.
    if args.mode == "preflight":
        try:
            credential(os.environ.get(TOKEN_ENV))
            result = report("ready_for_manual_run", "CREDENTIAL_PRESENT_NOT_VERIFIED")
        except Stop as exc:
            result = report(exc.status, exc.reason)
        result.update(transport="direct_https_only", max_requests=MAX_REQUESTS,
                      request_wall_seconds=REQUEST_SECONDS, total_budget_seconds=TOTAL_SECONDS,
                      subprocesses_started=0, auto_retry=False, production_config_changed=False)
    else:
        try:
            store = Store(state_root())
        except (OSError, RuntimeError):
            # Stop instead of guessing a different state location or losing the latch.
            result = report("blocked", "STATE_LOCATION_UNAVAILABLE")
        else:
            if args.mode == "status":
                try:
                    result = store.read()
                except Stop as exc:
                    result = report(exc.status, exc.reason)
            elif args.mode == "receive":
                result = receive(os.environ.get(TOKEN_ENV), store, args.approve_receipt)
            else:
                result = reconcile(os.environ.get(TOKEN_ENV), store, args.approve_read)
    # Pending receipt is non-sensitive, but keep the console summary short.
    visible = {k: v for k, v in result.items() if k != "pending_receipt"}
    print(json.dumps(visible, ensure_ascii=True, indent=2))
    return 0 if result["status"] in ("completed", "ready_for_manual_run") else 2


if __name__ == "__main__":
    mp.freeze_support()
    sys.exit(main())

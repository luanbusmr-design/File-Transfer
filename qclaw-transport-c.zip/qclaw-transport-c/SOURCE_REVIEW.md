# b 版截图复核与 c 版修改

复核日期：2026-09-14。
输入：本对话原始 qclaw-transport-b.zip 和用户提供的 QClaw 结果截图。
没有读取用户 Windows 原始终端日志，也没有更改其电脑、GitHub 或 Railway。

## 1. 原始 ZIP 完整性

ZIP：18,075 字节。
SHA256：1f6339cabd6aa8cf7c57b7c46489e3cb49385ebe9a1c59361c6b37f79fa13c50。
ZIP 包含 9 个文件。SHA256SUMS.json 内实际列出 8 个其他文件，不包含自身：

- DELIVERY_STATUS.md
- README.md
- qclaw_mailbox_b.py
- run_once.cmd
- run_preflight.cmd
- test-results.txt
- test-summary.json
- test_qclaw_mailbox_b.py

在本轮工作容器内重新计算，8/8 匹配。详见 original-manifest-check.json。
因此截图的“7/8，因为清单自含自身所以正常”与原包结构不符。
不能据截图确定电脑上哪个文件未被检查、是否缺失或执行器是否错误汇总；不猜测被篡改。
新验收入口逐一输出 8 行结果，不允许对不匹配项口头放行。

## 2. test_34 的确定源码问题

原 test_qclaw_mailbox_b.py 的 test_34 临时执行：

```python
with patch.dict(os.environ, {}, clear=True):
    # 包括其他只读性 mock
    b.main(["preflight"])
```

它临时清空测试进程环境，而不是证明用户 Windows 永久缺少用户目录。
原主程序 main 在分派 preflight 之前，先执行：

```python
store = Store(state_root())
```

state_root 在找不到 LOCALAPPDATA/XDG_STATE_HOME 时调用 Path.home()。
但 preflight 不需要读取或创建任何状态目录。这是程序启动顺序的缺陷。

Python 官方文档说明：Windows expanduser 使用 USERPROFILE，或 HOMEPATH/HOMEDRIVE；
自 Python 3.8 起不再用 HOME。Path.home 在无法解析用户目录时会抛 RuntimeError。
来源：
https://docs.python.org/3.13/library/os.path.html#os.path.expanduser
https://docs.python.org/3.13/library/pathlib.html#pathlib.Path.home

本轮在 Linux 显式模拟 Path.home 抛 RuntimeError，运行未修改的原 test_34，得到同一失败路径。
日志见 original-test34-reproduction.txt。这不是 Windows 真机复现，不声称拿到了截图背后的原 traceback。

修复针对主程序而非环境：preflight 不解析状态目录；其他模式需目录时才解析。
需要目录但无法解析时安全停止，不回退到另一个任务锁目录。
原 42 项测试未修改、不跳过。增加 8 个回归测试覆盖缺少用户目录、状态锁不重置、失败阻断和完整性核验。

## 3. 执行流程问题

截图报告了 41 OK、1 ERROR，随后仍执行 preflight。
这不符合此前“任一步失败即停止”的任务条件；不能因此把测试失败归类为正常授权关口。
c 的单一离线入口在任何测试错误/失败/跳过时不调用 preflight，该行为有回归测试。
不能靠跳过 test_34、填 HOME 或关闭沙箱来掩盖失败。

## 4. 本轮未完成的部分

用户 Windows 安装/复验、真实 GitHub 凭据验证、真实消息收发、自动接单和 phone-harness 均未在本容器执行。
这些材料及新包没有自动发送到 QClaw，不把本地生成文件等同于远端部署。

# QClaw 固定收发器 b

状态：代码与离线测试已完成；尚未在用户 Windows 电脑安装或验收。没有启动 QClaw、模型、网关或手机任务。

## 这一版解决什么

把“读 GitHub 消息 → 创建回执 → 读回核验”交给固定 Python 程序，不让 Agent 诊断网络或寻找凭据。
本版只接收已确认的 connectivity-b 握手消息，不是任意任务执行器，也没有常驻轮询。
成功只代表这台运行程序的电脑完成 GitHub 收发，不代表 QClaw/phone-harness 已接通。

- 代码分支：`qclaw-transport-b`，目录 `tools/qclaw_transport_b/`。
- 消息所在仓库：`luanbusmr-design/solo-company-hub`。
- 固定源提交：`add30037d2f89c228739ecbb4a3f3fbf59ddabfe`。
- 固定源文件：`handoffs/qclaw/connectivity-b.json`。
- 固定回执：`qclaw-bridge-a` 分支上的 `handoffs/qclaw/connectivity-b.result.json`。
- 固定源 blob：`75f5d4c90a48d8465b8fbd65fb391b988543bd0b`。

程序从实际读取并验哈希的源文件取得 test_id 和 nonce；不会拿本地测试样本伪装成远程接收。

## 已写进程序的边界

正常接收最多三个 HTTPS 请求：GET 源文件、PUT 创建回执、GET 按返回提交核验。
整轮共享 60 秒工作预算；每个网络步骤用独立子进程，父进程最多等待 15 秒，超时结束子进程。
预算包含 DNS/TLS/响应等待；剩余预算不足不启动下一步。操作系统调度、进程启动和本地文件系统完全失去响应时，不能把它当作实时操作系统级保证。

无重试、无代理切换、无重定向跟随、无 Git/gh/GCM、无 Shell 排障、无提权、无模型 SDK。
固定使用 HTTPS 直连 `api.github.com`，不继承 Git 或环境变量中的代理。系统 VPN/网络过滤仍可能影响它；失败只报告，绝不自动更换路线。

凭据只接受专用环境变量 `QCLAW_BRIDGE_GITHUB_TOKEN`，不枚举环境、不读 Windows 凭据管理器。
默认 preflight 不联网、不启动子进程、不写状态。凭据存在仅代表“已提供”，不代表授权有效。

首次网络尝试前创建持久任务标记。运行成功、失败或中断后，再运行同一任务都拒绝重放；关闭窗口再打开不能重置预算。
不提供自动清除锁、自动改 task_id 或自动恢复命令。不得由 Agent 删除状态目录以重跑。
回执 PUT 不带现有文件 SHA，是 create-only；已有回执时拒绝，不覆盖。

发送阶段超时、服务器错误或无法确认回执，状态为 unknown，不能直接重发。
经单独批准的 reconcile 最多做一次只读请求，不再次 PUT，不调用 QClaw。
本机日志和回执只含固定状态、测试标识和版本信息，不上传密钥、网关配置、屏幕、聊天历史或错误堆栈。

## Windows 一次性启动

保持 QClaw 暂停。将本包解压到普通本地文件夹，使用已有 Python 3.10+，不需要 pip install。
先双击 `run_preflight.cmd`，或在该目录运行：

```powershell
py -3 .\qclaw_mailbox_b.py preflight
```

如果没有 `py` 启动器，停止并报告，不让 Agent 自动安装 Python、换解释器或改系统设置。
如果显示 `GITHUB_AUTH_REQUIRED`，这是预期的授权关口，不是让 Agent 继续找令牌。

### 唯一需要的账户授权

使用你在本机专门提供的 GitHub 授权。新建 fine-grained PAT 时，仅选本仓库，Repository permissions 的 Contents = Read and write，设置短有效期；不需要 Administration、Workflows 或全仓库权限。
Contents write 是仓库内容权限，**不是仅一个文件或仅一个分支的服务端授权**；限制写入路径/分支由此程序执行，不等同于操作系统沙箱。
不要把令牌发送给 ChatGPT、QClaw、日志、截图或提交到 GitHub。ChatGPT 的 GitHub 连接不会自动把凭据交给你电脑。

GitHub 官方授权说明：
https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens

在本机 PowerShell 中一次性输入。输入内容不会直接写入命令历史，但令牌在本次进程及子进程内存/环境中仍为明文：

```powershell
$secure = Read-Host '专用 GitHub 令牌，仅在本机输入' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $env:QCLAW_BRIDGE_GITHUB_TOKEN = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    $secure.Dispose()
}
try {
    py -3 .\qclaw_mailbox_b.py receive --approve-receipt
} finally {
    Remove-Item Env:\QCLAW_BRIDGE_GITHUB_TOKEN -ErrorAction SilentlyContinue
}
```

输入授权所花时间不属于接收程序的 60 秒工作预算。不要在 QClaw 的对话执行窗口中输入令牌。
网络运行不会自动回复当前 ChatGPT 对话；成功回执保留在上面的固定 GitHub 路径。此前停用的回执监测未被本包重新启用。

## 输出与停止条件

| 状态 | 含义及处理 |
|---|---|
| needs_approval | 缺少明确授权或专用凭据；没有开始网络任务 |
| blocked | 当前动作失败或已被领取；停止，不自动排障 |
| unknown | 写入可能已经发生但未验证；不得重放 |
| completed | 回执已实际读回验证；不代表任何 Agent 任务成功 |
| running（日志） | 执行过程中的检查点；异常断电后可能残留，不证明仍有进程运行 |

`WORKER_START_DENIED` 只说明启动被拒绝，不推断是哪条系统策略；不换 cmd、Shell 或权限级别。
`HTTP_404_AMBIGUOUS` 不推断仓库不存在、私有状态或凭据是否过期。
`TASK_ALREADY_CLAIMED_NO_REPLAY` 是防重复标记，禁止自行删除它。

查看本地状态不联网：

```powershell
py -3 .\qclaw_mailbox_b.py status
```

仅当状态为 unknown、且用户明确批准一次只读核验时：

```powershell
py -3 .\qclaw_mailbox_b.py reconcile --approve-read
```

reconcile 也需要同一专用环境变量。它不修改远程文件；若仍无法确认，保持 unknown。
异常断电只留下 running 检查点时，本版不自动恢复或改写它。
Windows 状态目录：`%LOCALAPPDATA%\solo-company-hub\qclaw-transport-b\20260914-connectivity-b\`。
临时网络响应文件放在系统临时目录，正常退出时删除；强制终止整个进程可能留下临时文件，不包含 Authorization 头或令牌。

## 测试与未完成项

```powershell
py -3 -m unittest -v test_qclaw_mailbox_b
```

42 项测试通过，原始输出在 `test-results.txt`。环境为 Linux / Python 3.13.5。
测试包括模拟 GitHub 成功/失败、凭据缺失、拒绝启动、create-only、防重放、结果未知、只读核验、预算、来源哈希、错误脱敏。
另外真实启动了两个无网络测试子进程，其中一个先写入 started 标记再睡眠，父进程超时终止后确认没有遗留子进程。

这些不是 Windows 真机验收、不是真实 GitHub 身份验收、不是真实模型调用验收。
本包不安装常驻服务、不注册计划任务、不打开本机端口、不修改 Gateway/Tailscale/Railway/main。
下一阶段的自动取任务、限定 QClaw 调用预算和动作审批尚未实现；不能用本程序约束另行手动启动的 QClaw 自由排障会话。

实现参考：
https://docs.github.com/rest/repos/contents
https://docs.python.org/3/library/multiprocessing.html
https://docs.python.org/3/library/http.client.html

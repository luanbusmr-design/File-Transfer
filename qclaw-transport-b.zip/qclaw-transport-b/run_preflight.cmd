@echo off
setlocal
cd /d "%~dp0"
py -3 qclaw_mailbox_b.py preflight
set "RESULT=%ERRORLEVEL%"
echo.
echo Preflight finished. No retries, no agent calls. Exit code: %RESULT%
pause
exit /b %RESULT%

@echo off
setlocal
cd /d "%~dp0"
py -3 qclaw_mailbox_b.py receive --approve-receipt
set "RESULT=%ERRORLEVEL%"
echo.
echo Finished. Do not retry blocked or unknown tasks. Exit code: %RESULT%
pause
exit /b %RESULT%
